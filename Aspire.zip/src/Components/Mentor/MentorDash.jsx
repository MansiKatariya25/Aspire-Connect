import React from 'react'

function MentorDash() {
  return (
    <div>MentorDash</div>
  )
}

export default MentorDash