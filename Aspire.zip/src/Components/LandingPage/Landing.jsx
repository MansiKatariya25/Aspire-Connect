import React from 'react'
import Hero from './Hero'
import Hero2 from './Hero2'
import Hero3 from './Hero3'

function Landing() {
  return (
    <div >
      <Hero/>
      <Hero2/>
      <Hero3/>
    </div>
  )
}

export default Landing
