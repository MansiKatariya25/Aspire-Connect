package com.aspireconnect.AspireConnect.service;

public class Community {
    
}
