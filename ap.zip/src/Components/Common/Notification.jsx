import React from 'react'

function Notification() {
  return (
    <div className='absolute top-12 w-[85vw] h-[92vh] p-6 right-0 bg-white'>Notification</div>
  )
}

export default Notification